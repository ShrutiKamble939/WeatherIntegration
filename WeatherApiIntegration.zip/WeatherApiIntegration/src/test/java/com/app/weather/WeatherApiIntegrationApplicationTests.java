package com.app.weather;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherApiIntegrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
