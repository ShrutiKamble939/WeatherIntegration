package com.app.outbound;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter 	public class ResponseDto {

	private String status;
	private String msg;
}
