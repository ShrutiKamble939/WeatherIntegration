package com.app.outbound;

import javax.validation.constraints.NotBlank;

import lombok.Data;

@Data
public class RequestDto {
	
	@NotBlank(message = "City Name Must Be Supplied")
	private String cityname;
}
