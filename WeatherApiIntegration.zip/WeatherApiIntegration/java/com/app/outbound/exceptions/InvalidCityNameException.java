package com.app.outbound.exceptions;

public class InvalidCityNameException extends RuntimeException{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidCityNameException(String msg)
	{
		super(msg);
	}
}
