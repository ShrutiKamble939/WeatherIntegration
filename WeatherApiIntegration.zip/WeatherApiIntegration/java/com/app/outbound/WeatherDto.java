package com.app.outbound;

import lombok.Data;

@Data
public class WeatherDto {
	private String latitude;
	private String longitude;

	private String temperature;

	private String weather_description;
	private String feels_like;
	private String minimum_temperature;
	private String maximum_temperature;

}
