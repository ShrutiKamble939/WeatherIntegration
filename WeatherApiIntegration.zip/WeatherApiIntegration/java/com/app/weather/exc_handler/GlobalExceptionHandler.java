package com.app.weather.exc_handler;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.context.request.WebRequest;

import com.app.weather.exceptions.InvalidCityNameException;
import com.app.weather.outbound.ErrorDTO;

@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<ErrorDTO> customerExistsHandler(RuntimeException exc, WebRequest request) {
		ErrorDTO errorresponse = new ErrorDTO(request.getDescription(false), exc.getMessage(),
				LocalDateTime.now());
		return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(errorresponse);
	}
	
	@ExceptionHandler(HttpClientErrorException.class)
	public ResponseEntity<ErrorDTO> customerExistsHandler(HttpClientErrorException exc, WebRequest request) {
		ErrorDTO errorresponse = new ErrorDTO(request.getDescription(false), "INVALID API KEY SUPPLIED",
				LocalDateTime.now());
		return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(errorresponse);
	}
	
	
	@ExceptionHandler(InvalidCityNameException.class)
	public ResponseEntity<ErrorDTO> customerExistsHandler(InvalidCityNameException exc, WebRequest request) {
		ErrorDTO errorresponse = new ErrorDTO(request.getDescription(false), exc.getMessage(),
				LocalDateTime.now());
		return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(errorresponse);
	}
	

}
