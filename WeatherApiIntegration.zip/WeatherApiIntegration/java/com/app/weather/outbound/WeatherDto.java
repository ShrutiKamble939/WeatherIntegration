package com.app.weather.outbound;

import lombok.Builder;
import lombok.Data;
@Builder
@Data
public class WeatherDto {
	private String latitude;
	private String longitude;

	private String temperature;

	private String weather_description;
	private String feels_like;
	private String minimum_temperature;
	private String maximum_temperature;

}
