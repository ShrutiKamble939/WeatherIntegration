package com.app.weather.pojo;

public enum Units {
METRIC,STANDARD
}
