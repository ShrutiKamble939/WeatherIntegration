package com.app.weather.pojo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@ToString
@Builder(toBuilder = true) 
public class Weather {

	private String latitude;
	private String longitude;
	private String date;
	private Units units;
	private Credential credentials;
	
	
}
