package com.app.weather.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.weather.outbound.RequestDto;
import com.app.weather.outbound.WeatherDto;
import com.app.weather.service.IWeatherService;

import lombok.AllArgsConstructor;


/** 
 * @author Shruti Kamble
 * @apiNote
 * */

@AllArgsConstructor
@RestController
@RequestMapping(path = "/", produces = { MediaType.APPLICATION_JSON_VALUE },consumes = { MediaType.APPLICATION_JSON_VALUE })
public class WeatherController {
	
	IWeatherService service;

	@PostMapping("weather")
	public ResponseEntity<WeatherDto>  getCityWeatherInfo(@RequestBody RequestDto cityname) {
		
		return ResponseEntity.status(HttpStatus.OK).body(service.getWeatherInfo(cityname));
	}

}
