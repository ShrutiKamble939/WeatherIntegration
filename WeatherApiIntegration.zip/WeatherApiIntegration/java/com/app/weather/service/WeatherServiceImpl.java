package com.app.weather.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.app.weather.exceptions.InvalidCityNameException;
import com.app.weather.outbound.RequestDto;
import com.app.weather.outbound.WeatherDto;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class WeatherServiceImpl implements IWeatherService {

	@Value("${weather.weather_api_base_url}")
	private String weather_api_base_url;

	@Value("${weather.apikey}")
	private String apikey;

//
	public WeatherDto getWeatherInfo(RequestDto dto) throws RestClientException {
		
		
		if(dto.getCityname()!=null && dto.getCityname().length()==0) {
			throw new InvalidCityNameException("Please Provide City Name");
		}
		
		
		RestTemplate restemplate = new RestTemplate();
		System.out.println("WeatherServiceImpl.getWeatherInfo()");
		String weather_api_url = weather_api_base_url + dto.getCityname() + "&appid=" + apikey;
		
		log.info(weather_api_url);
		ResponseEntity<Object> apiResponse = restemplate.exchange(weather_api_url, HttpMethod.POST, null, Object.class);
		log.info("response code of the weather api is:\t" + apiResponse.getStatusCode().value());
		log.info("response \t" + apiResponse);
		ObjectMapper mapper = new ObjectMapper();
		String jsonString = null;
		JsonNode rootNode = null;
		
		try {
			jsonString = mapper.writeValueAsString(apiResponse.getBody());
			rootNode = mapper.readValue(jsonString, JsonNode.class);
			JsonNode coordNode = rootNode.path("coord");
			JsonNode weatherNode = rootNode.path("weather");
			JsonNode mainNode = rootNode.path("main");
			
			
			//builder pattern applied
			WeatherDto responsedto = WeatherDto.builder().latitude(coordNode.get("lat").toString())
					.longitude(coordNode.get("lon").toString())
					.weather_description(weatherNode.get(0).get("description").asText())
					.temperature(mainNode.get("temp").toString())
					.feels_like(mainNode.get("feels_like").toString())
					.minimum_temperature(mainNode.get("temp_min").toString())
					.maximum_temperature(mainNode.get("temp_max").toString()).build();
			
			
			return responsedto;
		} catch (Exception e) {
			return null;
		}

		
	}

}
