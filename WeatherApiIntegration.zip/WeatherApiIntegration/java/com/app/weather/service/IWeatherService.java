package com.app.weather.service;

import com.app.weather.outbound.RequestDto;
import com.app.weather.outbound.WeatherDto;

public interface IWeatherService {
	 WeatherDto getWeatherInfo(RequestDto cityname);
}
